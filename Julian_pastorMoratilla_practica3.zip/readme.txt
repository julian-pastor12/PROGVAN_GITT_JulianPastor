PREGUNTA 1 (Chatgpt)

Le he pasado la practica entera de primeras y le he dicho que trate de resolverla.

MINI-RESUMEN 1

Me ha entregado un cogigo que funcionaba pero había ciertos detalles que no había hecho bien.

PREGUNTA 2(Chatgpt)

seguro que esta bien?.

MINI-RESUMEN 2

Admite que ha tenido un error pero devuelve un código igual, sin cambiar nada.

PREGUNTA 3(Chatgpt)

Al seleccionar: 3. Crear una hora a partir de una cadena (formato HH:MM:SS) e introducir la hora 
con dicho formato no cambia la hora.

MINI-RESUMEN 3

Admite el error y lo corrige

PREGUNTA 4(Chatgpt)

en ningún caso la hora puede llegar a ser mas de 24 y con el formato AM o PM no puede pasar de 12,
al igual que los minutos y segundos no pueden pasar de 60.

MINI-RESUMEN 4

Admite el error pero sigue sin funcionar el codigo

PREGUNTA 5(Chatgpt)

Se ha corregido el error que te he comentado antes, pero habría que ajustar una cosa un poquito mas.
Tanto en formato AM como PM el reloj como tal nunca puede marcar 12, como máximo llegaría 11:59:59.
de la misma manera pasa con los minutos y los segundos en todos los formatos nunca pueden llegar a 60.

MINI-RESUMEN 5

Al especificar mas el problema ha sabido solucionarlo y ahora si funciona bien.

PREGUNTA 6(Chatgpt)

No se ha corregido, puedo llegar a introducir por ejemplo 12:29:30 AM, y esto es imposible.
Tienes que ajustar que en formato AM y PM no se pueda introducir en las horas 12 o mas.
Por cierto lo que te he comentado antes de los minutos y segundos si se ha solucionado.

MINI-RESUMEN 6

Realmente si funcionaba y cambio el codigo para hecerlo de otra manera que tambien funcionaba.

PREGUNTA 7(Chatgpt)

para la practica me piden: Todas las funciones/métodos deberán contener un docstring y seguir
la convención de nombres explicado en clase de teoría. 

MINI-RESUMEN 7

Ha cogido rl codigo que ya le había dicho que estaba bien y lo ha doucmentado.