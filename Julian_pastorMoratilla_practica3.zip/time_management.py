import re

class Time:
    """
    Clase que representa una hora en formato AM/PM o 24 horas.
    
    Atributos de clase:
        TIME_FORMATS (list): Lista de formatos válidos ("AM", "PM", "24 HOURS").
        time_count (int): Contador de objetos de la clase Time creados.

    Atributos de instancia:
        hours (int): Almacena las horas (1 a 11 para AM/PM, 0 a 23 para 24 horas).
        minutes (int): Almacena los minutos (0 a 59).
        seconds (int): Almacena los segundos (0 a 59).
        format (str): Almacena el formato de tiempo ("AM", "PM", "24 HOURS").
    """

    # Atributos de clase
    TIME_FORMATS = ["AM", "PM", "24 HOURS"]
    time_count = 0

    def __init__(self):
        """
        Método para inicializar los atributos de instancia en 0 y aumentar el contador de objetos.
        """
        self.hours = 0
        self.minutes = 0
        self.seconds = 0
        self.format = "24 HOURS"
        Time.time_count += 1

    def __asign_format(self, psz_format):
        """
        Asigna el formato de hora tras verificar si es válido.
        Convierte el formato a mayúsculas para evitar problemas de capitalización.

        Args:
            psz_format (str): Formato de hora ("AM", "PM", "24 HOURS").

        Returns:
            bool: True si el formato es válido y se asigna, False en caso contrario.
        """
        psz_format = psz_format.upper()
        if psz_format in self.TIME_FORMATS:
            self.format = psz_format
            return True
        return False

    def __is_24hour_format(self):
        """
        Comprueba si el formato de hora es "24 HOURS".

        Returns:
            bool: True si el formato es "24 HOURS", False en caso contrario.
        """
        return self.format == "24 HOURS"

    def _is_valid_time(self):
        """
        Verifica si la hora, minutos y segundos son válidos según el formato de hora.

        Returns:
            bool: True si la hora es válida, False en caso contrario.
        """
        if self.__is_24hour_format():
            # Validación de formato de 24 horas (0-23 para horas)
            return 0 <= self.hours <= 23 and 0 <= self.minutes < 60 and 0 <= self.seconds < 60
        elif self.format in ["AM", "PM"]:
            # Validación de formato AM/PM (1-11 para horas)
            return 1 <= self.hours <= 11 and 0 <= self.minutes < 60 and 0 <= self.seconds < 60
        return False

    def set_time(self, n_hours, n_minutes, n_seconds, psz_format):
        """
        Asigna una hora a la instancia de la clase Time tras validar los valores.

        Args:
            n_hours (int): Horas (1 a 11 para AM/PM, 0 a 23 para 24 horas).
            n_minutes (int): Minutos (0 a 59).
            n_seconds (int): Segundos (0 a 59).
            psz_format (str): Formato de hora ("AM", "PM" o "24 HOURS").

        Returns:
            bool: True si la hora se asignó correctamente, False en caso contrario.
        """
        if not (0 <= n_minutes < 60 and 0 <= n_seconds < 60):
            print("Minutos o segundos fuera de rango. Deben estar entre 0 y 59.")
            return False

        if self.__asign_format(psz_format):
            if self.__is_24hour_format() and 0 <= n_hours <= 23:
                self.hours = n_hours
            elif self.format in ["AM", "PM"]:
                if n_hours == 12:
                    print(f"Error: La hora '12' no es válida para el formato {self.format}.")
                    return False
                if 1 <= n_hours <= 11:
                    self.hours = n_hours
                else:
                    print(f"Hora inválida para el formato {self.format}.")
                    return False
            
            self.minutes = n_minutes
            self.seconds = n_seconds

            if self._is_valid_time():
                return True
            else:
                print("Error: La hora no es válida según el formato seleccionado.")
        else:
            print("Error: Formato de hora inválido.")
        return False

    def get_time(self):
        """
        Retorna la hora actual en formato "HH:MM:SS FORMAT".

        Returns:
            str: Hora actual en formato de cadena.
        """
        return f"{self.hours:02}:{self.minutes:02}:{self.seconds:02} {self.format}"

    @classmethod
    def from_string(cls, time_string):
        """
        Método de clase que crea un objeto Time a partir de una cadena.

        Args:
            time_string (str): Cadena con el formato "HH:MM:SS FORMAT", donde FORMAT es AM, PM o 24 HOURS.

        Returns:
            Time: Objeto Time creado con la hora parseada o None si la cadena es inválida.
        """
        # Patrón para coincidir con formato de hora con formato opcional
        pattern = r"(\d{2}):(\d{2}):(\d{2})(?:\s(AM|PM|24 HOURS))?"
        match = re.match(pattern, time_string.upper())
        if match:
            hours, minutes, seconds, format_time = match.groups()
            new_time = cls()
            
            # Si no se proporciona un formato, se asume "24 HOURS"
            if format_time is None:
                format_time = "24 HOURS"

            if new_time.set_time(int(hours), int(minutes), int(seconds), format_time):
                return new_time
        print("Formato de cadena de hora no válido.")
        return None

    @staticmethod
    def is_valid_format(time_format):
        """
        Método estático para verificar si un formato de hora es válido.

        Args:
            time_format (str): Formato de hora a comprobar.

        Returns:
            bool: True si el formato es válido, False en caso contrario.
        """
        return time_format.upper() in Time.TIME_FORMATS

    @classmethod
    def get_time_count(cls):
        """
        Método de clase que retorna el número total de objetos Time creados.

        Returns:
            int: Número de objetos Time creados.
        """
        return cls.time_count

def display_time_as_string(time_obj):
    """
    Función externa para mostrar la hora como cadena de texto.

    Args:
        time_obj (Time): Objeto Time del cual mostrar la hora.

    Returns:
        str: Hora formateada como "HH:MM:SS FORMAT".
    """
    return time_obj.get_time()

def main():
    """
    Función principal que ejecuta el menú interactivo.
    """
    current_time = Time()

    while True:
        print("\nMenu:")
        print("1. Introducir una nueva hora")
        print("2. Visualizar hora actual")
        print("3. Crear una hora a partir de una cadena (formato HH:MM:SS o HH:MM:SS FORMAT)")
        print("4. Terminar")

        choice = input("Seleccione una opción: ")

        if choice == "1":
            try:
                hours = int(input("Ingrese las horas: "))
                minutes = int(input("Ingrese los minutos: "))
                seconds = int(input("Ingrese los segundos: "))
                format_time = input("Ingrese el formato (AM, PM o 24 HOURS): ")
                if current_time.set_time(hours, minutes, seconds, format_time):
                    print("Hora asignada correctamente.")
                else:
                    print("Error al asignar la hora.")
            except ValueError:
                print("Entrada inválida. Por favor, introduzca números para horas, minutos y segundos.")

        elif choice == "2":
            print(f"Hora actual: {display_time_as_string(current_time)}")

        elif choice == "3":
            time_str = input("Ingrese la cadena de hora (formato HH:MM:SS o HH:MM:SS FORMAT): ")
            new_time = Time.from_string(time_str)
            if new_time:
                current_time = new_time
                print(f"Hora creada: {display_time_as_string(current_time)}")
            else:
                print("No se pudo crear la hora a partir de la cadena.")

        elif choice == "4":
            print("Terminando el programa...")
            break

        else:
            print("Opción no válida. Por favor, seleccione una opción del 1 al 4.")

if __name__ == "__main__":
    main()
